package com.sample.Springstandalone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.Springstandalone.entity.Employee;
import com.sample.Springstandalone.repository.EmployeeRespository;

@Service

public class EmployeeService {
	@Autowired
	private EmployeeRespository employeeRespository;

	@Transactional
	public void saveEmployee(List<Employee> employees) {
		employeeRespository.saveAll(employees);
		
	}
	
	
	public Employee findByName(String name) {
		Employee emp=employeeRespository.getEmployeeName(name);
		return emp;
	}
	
	public List<Employee> employeesortingByName(){
		return employeeRespository.employeesortingByName();
	}
	public void deleteEmployeeById(Integer empId){

		employeeRespository.deleteById(empId);


	}

}
