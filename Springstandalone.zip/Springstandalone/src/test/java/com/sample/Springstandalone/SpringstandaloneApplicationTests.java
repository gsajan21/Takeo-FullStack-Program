package com.sample.Springstandalone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringstandaloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
